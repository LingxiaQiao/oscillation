%% load data
load('oscillation_data.mat')
%% organize data
data = struct();
data.scZBZ055_20150404 = sc055_20150404; % single feedback (scZBZ055)
data.scZBZ055_20150507 = sc055_20150507; % single feedback (scZBZ055)
data.scZBZ097_20150606 = sc097_20150606; % double-layered feedback (non-repressilator, scZBZ097)
data.scZBZ097_20161207 = sc097_20161207; % double-layered feedback (non-repressilator, scZBZ097)
data.scZBZ237_20160424 = sc237_20160424; % double-layered feedback (repressilator, scZBZ237)
data.scZBZ237_20160425 = sc237_20160425; % double-layered feedback (repressilator, scZBZ237)


%% plot detected peaks
scname = fieldnames(data);
for i = 1:1
    figure(i)
    sgtitle(strrep(scname{i},'_','-'))
    scdata = data.(scname{i});
    cellnum = size(scdata,2);
    for j = 1:cellnum
        singlecell = smooth(scdata(:,j),'sgolay');
        subplot(10,ceil(cellnum/10),j)       
        findpeaks(singlecell,'MinPeakProminence',0.2,'MinPeakHeight',2)
        set(gca,'Ylim',[1,6])
        title(num2str(j))
    end
end

%% calculate cv of period and cv of amplitude
scname = fieldnames(data);
tp = cell(1,length(scname));
am = cell(1,length(scname));
cv_tp = zeros(1,length(scname));
cv_am = zeros(1,length(scname));

figure
for i = 1:length(scname)
    scdata = data.(scname{i});
    cellnum = size(scdata,2);
    tp_tmp = [];
    am_tmp = [];
    for j = 1:cellnum
        singlecell = smooth(scdata(:,j),'sgolay');
        [pks,locs] = findpeaks(singlecell,'MinPeakProminence',0.2,'MinPeakHeight',2);
        if length(pks)>1
            tp_tmp = [tp_tmp;diff(locs)];
            am_tmp = [am_tmp;pks];
        end
    end
    tp{i} = tp_tmp;
    am{i} = am_tmp;
    cv_tp(i) = std(tp_tmp)./mean(tp_tmp);
    cv_am(i) = std(am_tmp)./mean(am_tmp);
    subplot(2,length(scname),i)
    histogram(tp_tmp * 5,50);
    xlim([0,300])
    xlabel('peak distance (min)')
    title({strrep(scname{i},'_','-'),['CV of period = ',num2str(cv_tp(i))]})
    subplot(2,length(scname),length(scname) + i)
    histogram(am_tmp,50);
    xlim([2,7])
    title({strrep(scname{i},'_','-'),['CV of amplitude = ',num2str(cv_am(i))]})
    xlabel('amplitude (a.u.)')
end

%% CV of period
figure;
bar(1:3,[mean(cv_tp(1:2)),mean(cv_tp(3:4)),mean(cv_tp(5:6))],'FaceColor',[1,1,1],'LineWidth',1)
ylabel('% CV of period')
set(gca,'Xticklabel',{'single feedback (scZBZ055)',...
    'double-layered feedback (non-repressilator, scZBZ097)',...
    'double-layered feedback (repressilator, scZBZ237)'})
hold on
errorbar([mean(cv_tp(1:2)),mean(cv_tp(3:4)),mean(cv_tp(5:6))],...
    [std(cv_tp(1:2)),std(cv_tp(3:4)),std(cv_tp(5:6))],'k.','LineWidth',1,'CapSize',15)
xx = [1,1,2,2,3,3]+randn(1,6)/30;
plot(xx,cv_tp,'.','MarkerSize',30,'Color',[0.6,0.6,0.6])
